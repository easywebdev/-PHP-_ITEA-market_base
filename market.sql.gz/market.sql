-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 18 2018 г., 18:09
-- Версия сервера: 5.7.19
-- Версия PHP: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `market`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart_products`
--

CREATE TABLE `cart_products` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT '0',
  `anonymus` varchar(255) DEFAULT NULL,
  `count` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cpucash`
--

CREATE TABLE `cpucash` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `cash` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `cpucash`
--

INSERT INTO `cpucash` (`product_id`, `cash`) VALUES
(13, 3),
(14, 8),
(15, 12),
(16, 4),
(17, 6),
(18, 4),
(54, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

CREATE TABLE `images` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `delta` int(10) UNSIGNED NOT NULL,
  `size` double UNSIGNED NOT NULL,
  `path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `images`
--

INSERT INTO `images` (`id`, `product_id`, `delta`, `size`, `path`) VALUES
(6, 59, 0, 67.635, '../images/product_59/59_0.jpg'),
(7, 59, 1, 79.615, '../images/product_59/59_1.jpg'),
(8, 59, 2, 83.566, '../images/product_59/59_2.jpg'),
(9, 59, 3, 45.303, '../images/product_59/59_3.jpg'),
(10, 59, 4, 30.461, '../images/product_59/59_4.jpg'),
(11, 60, 0, 98.625, '../images/product_60/60_0.jpg'),
(12, 60, 1, 111.872, '../images/product_60/60_1.jpg'),
(13, 60, 2, 28.763, '../images/product_60/60_2.jpg'),
(14, 60, 3, 16.963, '../images/product_60/60_3.jpg'),
(15, 60, 4, 24.249, '../images/product_60/60_4.jpg'),
(41, 1, 0, 98.625, '../images/product_1/1_0.jpg'),
(42, 1, 1, 111.872, '../images/product_1/1_1.jpg'),
(43, 1, 2, 28.763, '../images/product_1/1_2.jpg'),
(44, 1, 3, 16.963, '../images/product_1/1_3.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `product_id`, `datetime`) VALUES
(1, 1, '2018-03-13 21:23:44'),
(2, 1, '2018-03-13 21:23:44'),
(3, 1, '2018-03-13 21:23:52'),
(4, 1, '2018-03-13 21:23:52'),
(5, 1, '2018-03-13 21:24:00'),
(6, 2, '2018-03-13 21:24:00'),
(7, 2, '2018-03-13 21:24:08'),
(8, 3, '2018-03-13 21:24:08'),
(17, 28, '2018-03-13 21:25:03'),
(18, 28, '2018-03-13 21:25:03'),
(19, 28, '2018-03-13 21:25:11'),
(20, 29, '2018-03-13 21:25:11'),
(21, 29, '2018-03-13 21:25:20'),
(22, 30, '2018-03-13 21:25:20'),
(23, 30, '2018-03-13 21:25:28'),
(24, 30, '2018-03-13 21:25:28'),
(25, 1, '2018-04-09 21:04:39'),
(26, 2, '2018-04-09 21:04:39'),
(27, 3, '2018-04-09 21:04:39'),
(28, 1, '2018-04-09 21:04:07'),
(29, 2, '2018-04-09 21:04:07'),
(30, 3, '2018-04-09 21:04:07'),
(31, 1, '2018-04-09 21:04:06'),
(32, 1, '2018-04-09 21:04:43'),
(33, 1, '2018-04-09 21:04:34'),
(34, 1, '2018-04-09 21:04:43'),
(35, 1, '2018-04-09 21:04:08'),
(36, 1, '2018-04-09 21:04:59'),
(37, 1, '2018-04-09 21:04:02'),
(38, 1, '2018-04-09 21:04:30'),
(39, 1, '2018-04-10 18:04:52'),
(40, 1, '2018-04-10 18:04:41'),
(41, 1, '2018-04-10 18:04:44'),
(42, 1, '2018-04-10 18:04:49'),
(43, 1, '2018-04-10 21:04:27'),
(44, 2, '2018-04-10 21:04:27'),
(45, 1, '2018-04-10 21:04:03'),
(46, 2, '2018-04-10 21:04:03'),
(47, 1, '2018-04-10 21:04:11'),
(48, 1, '2018-04-11 19:04:09'),
(49, 1, '2018-04-11 19:04:33'),
(50, 1, '2018-04-11 19:04:56'),
(51, 1, '2018-04-11 19:04:48'),
(52, 1, '2018-04-11 19:04:33'),
(53, 1, '2018-04-11 19:04:46'),
(54, 2, '2018-04-11 20:04:27'),
(55, 2, '2018-04-11 21:04:46'),
(56, 1, '2018-04-11 21:04:46'),
(57, 3, '2018-04-11 21:04:17'),
(58, 1, '2018-04-12 10:04:45'),
(59, 2, '2018-04-12 10:04:45'),
(60, 3, '2018-04-12 10:04:45'),
(62, 52, '2018-04-18 18:04:09');

-- --------------------------------------------------------

--
-- Структура таблицы `orders_products`
--

CREATE TABLE `orders_products` (
  `order_id` int(11) UNSIGNED NOT NULL,
  `product_id` int(11) UNSIGNED NOT NULL,
  `count` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `orders_products`
--

INSERT INTO `orders_products` (`order_id`, `product_id`, `count`) VALUES
(1, 1, 2),
(1, 2, 1),
(1, 3, 1),
(2, 1, 3),
(2, 2, 1),
(2, 3, 1),
(3, 1, 1),
(4, 1, 1),
(5, 1, 1),
(6, 1, 1),
(7, 1, 1),
(8, 1, 1),
(9, 1, 1),
(10, 1, 1),
(11, 1, 1),
(12, 1, 3),
(13, 1, 3),
(14, 1, 3),
(15, 1, 1),
(15, 2, 1),
(16, 1, 1),
(16, 2, 1),
(17, 1, 1),
(18, 1, 1),
(19, 1, 1),
(20, 1, 1),
(21, 1, 1),
(22, 1, 1),
(23, 1, 1),
(24, 2, 2),
(25, 2, 1),
(25, 1, 2),
(26, 3, 1),
(27, 1, 5),
(27, 2, 1),
(27, 3, 1),
(30, 52, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `processor`
--

CREATE TABLE `processor` (
  `id` int(10) UNSIGNED NOT NULL,
  `model` varchar(255) NOT NULL,
  `cores_count` tinyint(10) UNSIGNED NOT NULL,
  `clock_speed` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `processor`
--

INSERT INTO `processor` (`id`, `model`, `cores_count`, `clock_speed`) VALUES
(1, 'AMD Dual-Core A6-9220', 2, 2.9),
(2, 'Intel Pentium N3710', 2, 2.6),
(3, 'Intel Pentium N4200', 2, 2.5),
(4, 'ARM Cortex-A7', 4, 1.3),
(5, 'MT6753', 8, 1.3),
(6, 'T-Shark 2', 4, 1.3),
(7, 'MediaTek MT8321', 4, 1.3),
(8, 'MTK MT8163B', 4, 1.3);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL,
  `type` varchar(255) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `type`, `datetime`) VALUES
(1, 'Lenovo IdeaPad 320-15AST', 'Екран 15.6\" (1366x768) HD, матовий / AMD Dual-Core A6-9220 (2.5 - 2.9 ГГц) / RAM 4 ГБ / HDD 500 ГБ / AMD Radeon R5 / без ОД / LAN / Wi-Fi / Bluetooth / веб-камера / DOS / 2.2 кг / чорний_edit', 7399, 'laptops', '2018-03-08 18:00:47'),
(2, 'HP 255 G6 (2EW01ES)', 'Екран 15.6\" (1366x768) WXGA HD, матовий / AMD Dual-Core A6-9220 (2.5 - 2.9 ГГц) / RAM 4 ГБ / HDD 500 ГБ / AMD Radeon R4 / без ОД / LAN / Wi-Fi / Bluetooth / веб-камера / DOS / 1.86 кг / чорний', 7599, 'laptops', '2018-03-08 18:00:47'),
(3, 'HP 255 G6 (2HH04ES)', 'Екран 15.6\" (1366x768) WXGA HD, матовий / AMD Dual-Core A6-9220 (2.5 - 2.9 ГГц) / RAM 4 ГБ / HDD 1 ТБ / AMD Radeon R4 / без ОД / LAN / Wi-Fi / Bluetooth / веб-камера / DOS / 1.86 кг / чорний', 7699, 'laptops', '2018-03-08 18:04:00'),
(6, 'Dell Inspiron 3552 (35P374H5IHD-LBK)', 'Экран 15.6\" (1366x768) HD, глянцевый / Intel Pentium N3710 (1.6 - 2.56 ГГц) / RAM 4 ГБ / HDD 500 ГБ / Intel HD Graphics 405 / DVD±RW / Wi-Fi / Bluetooth / веб-камера / Linux / 2.14 кг / черный', 7895, 'laptops', '2018-03-08 18:06:36'),
(7, 'Huawei MediaPad T3 7\"', 'Экран 7.0\" IPS (1024x600) MultiTouch / MediaTek MT8127 (1.3 ГГц) / RAM 1 ГБ / 8 ГБ встроенной памяти + microSD / Wi-Fi / Bluetooth / основная камера 2 Мп, фронтальная 2 Мп / GPS / Android 6.0 (Marshmallow) / 250 г / серый', 2199, 'tablets', '2018-03-08 18:22:41'),
(8, 'Pixus Vision 10.1 3G', 'Екран 10.1\" IPS (1920x1200) MultiTouch / MediaTek MT6753 (1.3 ГГц) / RAM 2 ГБ / 16 ГБ вбудованої пам\'яті + microSD / 3G / LTE / Wi-Fi / Bluetooth 4.0 / основна камера 5 Мп, фронтальна - 2 Мп / GPS / A-GPS / підтримка 2 СІМ-карток / Android 7.0 (Nougat) / 450 г / чорний', 3999, 'tablets', '2018-03-08 18:22:41'),
(9, 'Samsung Galaxy Tab E 9.6\" 3G', 'Екран 9.6\" (1280x800) ємнісний MultiTouch / T-Shark2 (1.3 ГГц) / RAM 1.5 ГБ / 8 ГБ вбудованої пам\'яті + microSD / 3G / Wi-Fi 802.11a/b/g/n / Bluetooth 4.0 / основна камера 5 Мп, фронтальна 2 Мп / GPS / ГЛОНАСС / Android 4.4 (KitKat) / 490 г / чорний', 4999, 'tablets', '2018-03-08 18:25:43'),
(10, 'Prestigio Muze 3708 3G', 'Екран 8\" IPS (1280x800) MultiTouch / MediaTek MT8321 (1.3 ГГц) / RAM 1 ГБ / 16 ГБ вбудованої пам\'яті + microSD (до 32 ГБ) / 3G / Wi-Fi / Bluetooth 4.0 / основна камера 2 Мп, фронтальна - 0.3 Мп / GPS / підтримка 2 СІМ-карток / Android 7.0 (Nougat) / 360 г / чорний', 2499, 'tablets', '2018-03-08 18:25:43'),
(11, 'Asus ZenPad 10 2/16GB Wi-Fi', 'Екран 10.1\" IPS (1280x800) ємнісний MultiTouch / MediaTek MT8163B (1.3 ГГц) / RAM 2 ГБ / 16 ГБ вбудованої пам\'яті + microSD / Wi-Fi 802.11 b / g / n / Bluetooth 4.1 / основна камера 5 Мп, фронтальна - 2 Мп / GPS / ГЛОНАСС / ОС Android 7.0 / 490 г / темно-сірий', 5099, 'tablets', '2018-03-08 18:29:43'),
(12, 'Asus ZenPad 8.0 16GB', 'Екран 8\" IPS (1280x800) ємнісний MultiTouch / MediaTek MT8163 (1.3 ГГц) / RAM 2 ГБ / 16 ГБ вбудованої пам\'яті + microSD / Wi-Fi 802.11 a/b/g/n / Bluetooth 4.0 / основна камера 5 Мп, фронтальна - 2 Мп / GPS / ОС Android 6.0 / 350 г / темно-сірий', 4299, 'tablets', '2018-03-08 18:29:43'),
(13, 'Intel Pentium G4560 3.5GHz/8GT/s/3MB', 'Процесор Intel Pentium 7-го покоління, з кодовою назвою мікроархітектури Kaby Lake. Платформа нового покоління Intel Pentium пропонує продуктивність, необхідну в повсякденних обчисленнях і новітні можливості, як-від сенсорний ввід і технологія Intel Ready Mode, що забезпечують «постійну готовність ПК до роботи».', 1770, 'processors', '2018-03-08 18:44:50'),
(14, 'Intel Core i7-7700K 4.2GHz/8GT/s/8MB', 'Новий процесор Intel Core i7-7700K 7-го покоління, з кодовою назвою мікроархітектури Kaby Lake. Призначений для настільної платформи Intel LGA 1151. Належить до сімейства високопродуктивних процесорів Core i7 з великим розгінним потенціалом.', 10525, 'processors', '2018-03-08 18:44:50'),
(15, 'Intel Core i7-8700K 3.7GHz/8GT/s/12MB', 'Новий процесор Intel Core i7-8700K 8-го покоління, з кодовою назвою мікроархітектури Coffee Lake. Призначений для настільної платформи Intel LGA 1151. Належить до сімейства високопродуктивних процесорів Core i7.', 11676, 'processors', '2018-03-08 18:49:37'),
(16, 'AMD Ryzen 5 2400G 3.6GHz / 4MB', 'Процесор AMD Ryzen із вбудованою графікою Radeon Vega має одні з найбільш передових і потужних обчислювальних і графічних різновидів апаратного обладнання, доступних на сьогодні, об\'єднаних в одному процесорі для забезпечення високої продуктивності, необхідної для великих робочих навантажень і ресурсомістких ігор без компромісів.', 5600, 'processors', '2018-03-08 18:49:37'),
(17, 'Intel Core i5-7500 3.4GHz/8GT/s/6MB', 'Новий процесор Intel Core i5-7500 7-го покоління, з кодовою назвою мікроархітектури Kaby Lake. Призначений для настільної платформи Intel LGA 1151. Належить до сімейства високопродуктивних процесорів Core i5.', 6073, 'processors', '2018-03-08 18:52:48'),
(18, 'AMD Ryzen 3 2200G 3.5GHz / 4MB', 'Процесор AMD Ryzen із вбудованою графікою Radeon Vega має одні з найбільш передових і потужних обчислювальних і графічних різновидів апаратного обладнання, доступних на сьогодні, об\'єднаних в одному процесорі для забезпечення високої продуктивності, необхідної для великих робочих навантажень і ресурсомістких ігор без компромісів.', 3550, 'processors', '2018-03-08 18:52:48'),
(19, 'Asus Expedition EX-B250-V7', 'Материнська плата ASUS Expedition готова до тривалого бою.\r\nМатеринські плати ASUS Expedition призначені для дій, спроектованих із неперевершеною довговічністю для запобігання пошкодженню від вологи, корозії та перенапруг — для довголіття. Пам\'ять заблокована для забезпечення максимальної безпеки. Їх тестували на межі, зі 144 годинами бездискових системних тестів і великими перевірками сумісності з топ-іграми та понад 100 ігровими периферійними пристроями. Для звуку материнські плати Expedition мають Crystal Sound 2. Плата забезпечить безупинну продуктивність — кращу', 3055, 'motherboards', '2018-03-08 18:56:55'),
(20, 'Asus H110M-K', 'H110M-K — функціональна материнська плата Asus формату micro-ATX початкового рівня, призначена для нової платформи Intel і базується на системній логіці H110. Підтримує 2 слоти оперативної пам\'яті DDR4.\r\n\r\nIntel H110 Express — це новітній чипсет, оптимізований для роботи з процесорами Intel Core i7/i5/i3/Pentium/Celeron 6-го та 7-го поколінь, що встановлюються в роз\'єм LGA 1151. Він вирізняється високою стабільністю, продуктивністю і пропускною здатністю. Intel H110 дає змогу використовувати вбудоване графічне ядро', 1518, 'motherboards', '2018-03-08 18:56:55'),
(21, 'MSI B250M Pro-VD', 'Материнські плати PRO Series підійдуть для будь-якого ПК. Якість, гідна довіри, висока продуктивність та інтелектуальні рішення для бізнесу — це ключові ознаки цих материнських плат. Зробіть своє життя простішим та надайте своєму бізнесу підтримку із суперстабільними, надійними та довговічними платами PRO Series.', 2093, 'motherboards', '2018-03-08 19:00:17'),
(22, 'Asus Prime B250-Plus', 'Повнофункціональна материнська плата Asus Prime B250-Plus формату ATX, призначена для нової платформи Intel і базується на системній логіці B250.', 2870, 'motherboards', '2018-03-08 19:00:17'),
(23, 'Asus Prime B250M-K', 'Повнофункціональна материнська плата Asus Prime B250M-K формату micro-ATX, призначена для нової платформи Intel і базується на системній логіці B250.', 2250, 'motherboards', '2018-03-08 19:03:32'),
(24, 'MSI B250m Gaming Pro', 'MSI Gaming — це материнські плати, розроблені, щоб надати гравцям найкращі у своєму класі функції й технології. Кожна материнська плата є шедевром інженерного мистецтва й уособлює геймерський ідеал.', 2426, 'motherboards', '2018-03-08 19:03:32'),
(25, 'INNO3D PCI-Ex GeForce GTX1060 Compact 6GB GDDR5', 'INNO3D GeForce GTX1060 Compact ґрунтується на новій архітектурі Pascal, а також має на борту 6 ГБ пам\'яті GDDR5. Підтримує гранично високу роздільну здатність екрана! Відеокарта обладнана компактною системою охолодження з одним вентилятором і радіатором.', 11999, 'graphic cards', '2018-03-08 19:08:29'),
(26, 'Asus PCI-Ex GeForce GTX 1050 ROG Strix OC 2GB GDDR5', 'GeForce GTX 1050 Compact\r\nGeForce GTX 1050 Compact ґрунтується на новій архітектурі Pascal, а також має на борту 2 ГБ пам\'яті GDDR5. Підтримує максимально допустиму роздільну здатність дисплея!\r\nВідеокарта обладнана компактною системою охолодження з одним вентилятором і компактним радіатором.', 5250, 'graphic cards', '2018-03-08 19:08:29'),
(27, 'Gigabyte PCI-Ex GeForce GT 710 1024MB GDDR5', 'Оновіть своє графічне рішення до нової дискретної відеокарти GeForce GT 710 і матимете супершвидку роботу в Інтернет, а також неймовірні можливості редагування фото і відео', 1369, 'graphic cards', '2018-03-08 19:12:22'),
(28, 'Asus PCI-Ex GeForce GTX 1070 Expedition 8GB GDDR5', 'Відеокарта GeForce GTX 1070 Expedition від Asus, обсягом пам\'яті 8 ГБ GDDR5, ґрунтується на новій архітектурі Pascal і підтримує гранично високу роздільну здатність екрана. Ексклюзивна технологія Auto-Extreme використовує компоненти Super Alloy Power II, гарантує чудову стабільність. GPU Tweak II з XSplit Gamecaster забезпечує інтуїтивно тонке калібрування продуктивності та невпинний ігровий стріминг.', 22569, 'graphic cards', '2018-03-08 19:12:22'),
(29, 'Asus PCI-Ex Radeon RX570 ROG Strix OC 4GB GDDR5', 'ASUS ROG Strix\r\nROG Strix — це нова серія геймерських пристроїв у межах бренду Republic of Gamers. Їхньою відмітною особливістю є найвища продуктивність, використання інноваційних технологій, бездоганний рівень надійності та стильний дизайн, що підкреслює індивідуальність кожного геймера. Пристрої серії ROG Strix — це швидкість і функціональність, необхідна для перемоги у будь-якій грі!', 13899, 'graphic cards', '2018-03-08 19:16:10'),
(30, 'Asus PCI-Ex Radeon RX Vega 56 8192MB HBM2', 'Відеокарта ROG Strix RX VEGA56 — це геймерська модель вищого класу, обладнана безліччю ексклюзивних технологій ASUS. Система охолодження, що використовується на ній, може похвалитися високою ефективністю завдяки пилонепроникним вентиляторам з оптимізованою геометрією крильчатки, а можливість під\'єднання 4-контактних корпусних вентиляторів дасть змогу забезпечити максимально комфортний для такого потужного пристрою температурний режим. Система підсвітки Aura Sync допоможе зробити дизайн комп\'ютера незабутнім за допомогою оригінальних світлових ефектів, водночас сумісні з VR-пристроями порти HDMI подарують', 30999, 'graphic cards', '2018-03-08 19:16:10'),
(31, 'Ноутбук Yepo 737G (737G464)', 'Экран 15.6\" (1920x1080) Full HD, матовый / Intel Atom x5-Z8350 (1.44 -1.92 ГГц) / RAM 4 ГБ / eMMC 64 ГБ / Intel HD Graphics / без ОД / Wi-Fi / Bluetooth / веб-камера / DOS / 1.8 кг / серебристый', 4749, 'laptops', '2018-03-25 16:07:52'),
(32, 'Ноутбук Prestigio SmartBook 116C', 'Екран 11.6\" IPS (1920x1080) Full HD, матовий / Intel Atom x5-Z8350 (1.44 - 1.92 ГГц) / RAM 2 ГБ / eMMC 32 ГБ / Intel HD Graphics 400 / без ОД / Wi-Fi / Bluetooth / веб-камера / Windows 10 Pro / 1.06 кг / чорний', 5599, 'laptops', '2018-03-25 16:18:31'),
(33, 'Ноутбук Prestigio SmartBook 141C', 'Екран 14.1\" IPS (1920x1080) Full HD, матовий / Intel Atom x5-Z8350 (1.44 - 1.92 ГГц) / RAM 2 ГБ / eMMC 32 ГБ / Intel HD Graphics 400 / без ОД / Wi-Fi / Bluetooth / веб-камера / Windows 10 Pro / 1.45 кг / білий', 5699, 'laptops', '2018-03-25 16:29:17'),
(34, 'Ноутбук Lenovo IdeaPad 110-15IBR', 'Екран 15.6\" (1366x768) HD, глянсовий / Intel Celeron N3060 (1.6 - 2.48 ГГц) / RAM 2 ГБ / HDD 500 ГБ / Intel HD Graphics 400 / без ОД / LAN / Wi-Fi / Bluetooth / веб-камера / DOS / 2.2 кг / чорний', 6199, 'laptops', '2018-03-25 17:03:23'),
(35, 'Ноутбук Lenovo IdeaPad 110-15IBR', 'Екран 15.6\" (1366x768) HD, глянсовий / Intel Celeron N3060 (1.6 - 2.48 ГГц) / RAM 2 ГБ / HDD 500 ГБ / Intel HD Graphics 400 / без ОД / LAN / Wi-Fi / Bluetooth / веб-камера / DOS / 2.2 кг / чорний', 6199, 'laptops', '2018-03-25 17:05:39'),
(36, 'Ноутбук Lenovo IdeaPad 110-15IBR', 'Екран 15.6\" (1366x768) HD, глянсовий / Intel Celeron N3060 (1.6 - 2.48 ГГц) / RAM 2 ГБ / HDD 500 ГБ / Intel HD Graphics 400 / без ОД / LAN / Wi-Fi / Bluetooth / веб-камера / DOS / 2.2 кг / чорний', 6199, 'laptops', '2018-03-25 17:06:04'),
(52, 'Ноутбук Acer Aspire ES1-132-C2L5', 'Екран 11.6\" (1366x768) HD, матовий / Intel Celeron N3350 (1.1 - 2.4 ГГц) / RAM 2 ГБ / eMMC 32 ГБ / Intel HD Graphics 500 / без ОД / Wi-Fi / Bluetooth / веб-камера / Linux / 1.25 кг / чорний', 6549, 'laptops', '2018-03-25 19:05:51'),
(53, 'Планшет Lenovo Tab4 7 Essential TB-7304X LTE', 'Екран 7\" IPS (1024х600), MultiTouch/MediaTek MT8735D (1.1 ГГц) / RAM 1 ГБ / 16 ГБ вбудованої пам\'яті + microSD / Wi-Fi/ 3G / 4G / Bluetooth 4.0 / основна камера 2 Мп + фронтальна – 2 Мп / A-GPS / Android 7.0 (Nougat) / 254 г ', 3399, 'laptops', '2018-03-25 19:36:08'),
(54, 'Intel Core i5-8400', 'Процесор Intel Core i5-8400 2.8GHz/8GT/s/9MB (BX80684I58400) s1151 BOX', 5895, 'processors', '2018-03-25 21:48:56'),
(55, 'ASRock H81M-HDS R2.0', 'Материнська плата ASRock H81M-HDS R2.0 (s1150, H81, PCI-Ex16)', 1360, 'motherboards', '2018-03-25 21:54:03'),
(56, 'GeForce GT 730', 'MSI PCI-Ex GeForce GT 730 1024MB DDR3 (64bit) (1006/1600) (VGA, DVI, HDMI) (N730K-1GD3/OCV2)', 1789, 'graphic cards', '2018-03-25 21:57:43'),
(57, 'Radeon RX 580', 'MSI PCI-Ex Radeon RX 580 Gaming X 4GB GDDR5 (256bit) (1380/7000) (DVI, 2 x HDMI, 2 x DisplayPort) (Radeon RX 580 GAMING X 4G)', 14417, 'graphic cards', '2018-03-26 21:59:01'),
(59, 'Lenovo IdeaPad 320-15ISK', 'Екран 15.6\" (1920x1080) Full HD, матовий / Intel Core i3-6006U (2.0 ГГц) / RAM 8 ГБ / SSD 256 ГБ / nVidia GeForce GT 920MX, 2 ГБ / без ОД / LAN / Wi-Fi / Bluetooth / веб-камера / DOS / 2.2 кг / чорний', 137777, 'laptops', '2018-03-28 20:35:56'),
(60, 'Apple A1706 MacBook Pro TB Retina 13', 'Екран 13.3\" IPS (2560x1600) Retina, глянсовий / Intel Core i5 (3.1 - 3.5 ГГц) / RAM 8 ГБ / SSD 512 ГБ / Intel Iris Graphics 650 / без ОД / Wi-Fi / Bluetooth / веб-камера / macOS Sierra / 1.37 кг', 65399, 'laptops', '2018-03-28 20:43:12');

-- --------------------------------------------------------

--
-- Структура таблицы `products_processors`
--

CREATE TABLE `products_processors` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `processor_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `products_processors`
--

INSERT INTO `products_processors` (`product_id`, `processor_id`) VALUES
(1, 2),
(2, 1),
(3, 1),
(6, 2),
(7, 4),
(8, 5),
(9, 6),
(10, 7),
(11, 8),
(12, 8),
(31, 2),
(32, 1),
(33, 1),
(35, 1),
(36, 1),
(52, 3),
(53, 1),
(59, 3),
(60, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `products_screens`
--

CREATE TABLE `products_screens` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `screen_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `products_screens`
--

INSERT INTO `products_screens` (`product_id`, `screen_id`) VALUES
(1, 6),
(2, 2),
(3, 3),
(6, 6),
(7, 7),
(8, 8),
(11, 11),
(12, 12),
(9, 9),
(10, 10),
(31, 3),
(32, 2),
(33, 2),
(35, 1),
(36, 1),
(52, 2),
(53, 7),
(59, 1),
(60, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `ram`
--

CREATE TABLE `ram` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `memory` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `ram`
--

INSERT INTO `ram` (`product_id`, `memory`) VALUES
(1, 4),
(2, 4),
(3, 4),
(6, 4),
(7, 8),
(8, 16),
(25, 6),
(26, 2),
(27, 1),
(28, 8),
(29, 4),
(30, 8),
(31, 4),
(32, 2),
(33, 2),
(36, 2),
(52, 2),
(53, 16),
(56, 1),
(57, 4),
(59, 8),
(60, 8);

-- --------------------------------------------------------

--
-- Структура таблицы `screen`
--

CREATE TABLE `screen` (
  `id` int(10) UNSIGNED NOT NULL,
  `size` float UNSIGNED NOT NULL,
  `matrix` enum('TN','ISP') NOT NULL,
  `matrix_type` enum('mat','glossy') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `screen`
--

INSERT INTO `screen` (`id`, `size`, `matrix`, `matrix_type`) VALUES
(1, 15.6, 'TN', 'mat'),
(2, 15.6, 'ISP', 'mat'),
(3, 15.6, 'TN', 'mat'),
(4, 15.6, 'ISP', 'glossy'),
(5, 15.6, 'TN', 'glossy'),
(6, 15.6, 'ISP', 'mat'),
(7, 7, 'TN', 'glossy'),
(8, 10.1, 'TN', 'glossy'),
(9, 9.6, 'ISP', 'mat'),
(10, 8, 'ISP', 'mat'),
(11, 10.1, 'ISP', 'mat'),
(12, 8, 'ISP', 'glossy');

-- --------------------------------------------------------

--
-- Структура таблицы `socket`
--

CREATE TABLE `socket` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `socket` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `socket`
--

INSERT INTO `socket` (`product_id`, `socket`) VALUES
(13, 'LGA 1151'),
(14, 'LGA 1151'),
(15, 'LGA 1151'),
(16, 'AM3+'),
(17, 'LGA 1151'),
(18, 'AM3+'),
(19, 'LGA 1151'),
(20, 'LGA 1151'),
(21, 'LGA 1151'),
(22, 'AM3+'),
(23, 'AM3+'),
(24, 'AM3+'),
(54, 'LGA 1151'),
(55, 'LGA 1151');

-- --------------------------------------------------------

--
-- Структура таблицы `uorders`
--

CREATE TABLE `uorders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `uorders`
--

INSERT INTO `uorders` (`id`, `user_id`, `address`, `datetime`) VALUES
(1, 'b98a3773ecf715751d3cf0fb6dcba424', 'Vatindik', '2018-04-09 18:04:39'),
(2, 'b98a3773ecf715751d3cf0fb6dcba424', 'Vatindik', '2018-04-09 18:04:07'),
(3, 'b98a3773ecf715751d3cf0fb6dcba424', 'Vatindik', '2018-04-09 18:04:06'),
(4, 'b98a3773ecf715751d3cf0fb6dcba424', 'Vatindik', '2018-04-09 18:04:43'),
(5, 'b98a3773ecf715751d3cf0fb6dcba424', 'Vatindik', '2018-04-09 18:04:34'),
(6, 'b98a3773ecf715751d3cf0fb6dcba424', 'Vatindik', '2018-04-09 18:04:43'),
(7, 'b98a3773ecf715751d3cf0fb6dcba424', 'Vatindik', '2018-04-09 18:04:08'),
(8, 'b98a3773ecf715751d3cf0fb6dcba424', 'Vatindik', '2018-04-09 18:04:59'),
(9, 'b98a3773ecf715751d3cf0fb6dcba424', '', '2018-04-09 18:04:02'),
(10, 'b98a3773ecf715751d3cf0fb6dcba424', 'Vatindik', '2018-04-09 18:04:30'),
(11, '250413d2982f1f83aa62a3a323cd2a87', 'aaa', '2018-04-10 15:04:52'),
(12, '12', '', '2018-04-10 15:04:41'),
(13, '12', '', '2018-04-10 15:04:44'),
(14, '12', 'aaa', '2018-04-10 15:04:49'),
(15, '12', 'aaa', '2018-04-10 18:04:27'),
(16, '12', 'aaaa', '2018-04-10 18:04:03'),
(17, '12', 'aaa', '2018-04-10 18:04:11'),
(18, '29c08a4baebd25af6a2acf659cf834e8', 'aaa', '2018-04-11 16:04:09'),
(19, '29c08a4baebd25af6a2acf659cf834e8', 'aaa', '2018-04-11 16:04:33'),
(20, '29c08a4baebd25af6a2acf659cf834e8', 'aaa', '2018-04-11 16:04:56'),
(21, '29c08a4baebd25af6a2acf659cf834e8', '', '2018-04-11 16:04:48'),
(22, '12', 'aaa', '2018-04-11 16:04:33'),
(23, '12', 'aaa', '2018-04-11 16:04:46'),
(24, '12', 'aaa', '2018-04-11 17:04:27'),
(25, '12', 'aaa', '2018-04-11 18:04:46'),
(26, '12', 'aaa', '2018-04-11 18:04:17'),
(27, '12', 'ccc', '2018-04-12 07:04:45'),
(28, '12', 'aaa', '2018-04-12 18:04:47'),
(29, '18', 'xxxxxx', '2018-04-18 14:04:56'),
(30, '18', 'cccc', '2018-04-18 15:04:09');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_access` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fullname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `pass`, `email`, `status`, `created`, `last_access`, `fullname`) VALUES
(2, 'aaa', '202cb962ac59075b964b07152d234b70', 'a@bb.ua', 0, '2018-03-30 16:45:19', '2018-03-30 16:45:19', 'AAA BBBB'),
(3, 'bbb', '202cb962ac59075b964b07152d234b70', 'aaa@gmail.com', 0, '2018-03-30 17:29:04', '2018-03-30 17:29:04', 'AAA BBBB'),
(4, 'a1', '202cb962ac59075b964b07152d234b70', 'a1@bb.ua', 0, '2018-03-30 17:47:27', '2018-03-30 17:47:27', 'AAA BBBB'),
(5, 'a2', '202cb962ac59075b964b07152d234b70', 'a2@bb.ua', 0, '2018-03-30 17:59:01', '2018-03-30 17:59:01', 'AAA BBBB'),
(6, 'a3', '202cb962ac59075b964b07152d234b70', 'a3@bb.ua', 0, '2018-03-30 18:09:59', '2018-03-30 18:09:59', 'AAA BBBB'),
(7, 'a4', '202cb962ac59075b964b07152d234b70', 'a4@bb.ua', 0, '2018-04-01 15:42:35', '2018-04-01 15:42:35', 'AAA BBBB'),
(8, 'a5', '202cb962ac59075b964b07152d234b70', 'a5@bb.ua', 0, '2018-04-01 15:46:28', '2018-04-01 15:46:28', 'AAA BBBB'),
(9, 'a6', '202cb962ac59075b964b07152d234b70', 'a6@bb.ua', 1, '2018-04-01 15:52:49', '2018-04-01 15:52:49', 'AAA BBBB'),
(10, 'a7', '202cb962ac59075b964b07152d234b70', 'a7@bb.ua', 0, '2018-04-01 16:39:40', '2018-04-01 16:39:40', 'AAA BBBB'),
(11, 'a8', '202cb962ac59075b964b07152d234b70', 'a8@bb.ua', 1, '2018-04-01 16:41:15', '2018-04-01 16:41:15', 'AAA BBBB'),
(12, 'a9', '202cb962ac59075b964b07152d234b70', 'a9@bb.ua', 1, '2018-04-01 16:43:48', '2018-04-01 16:43:48', 'AAA BBBB'),
(13, 'a10', '202cb962ac59075b964b07152d234b70', 'a10@bb.ua', 1, '2018-04-01 16:57:29', '2018-04-01 16:57:29', 'AAA BBBB'),
(14, 'a11', '202cb962ac59075b964b07152d234b70', 'a11@bb.ua', 1, '2018-04-01 17:10:24', '2018-04-01 17:10:24', 'AAA BBBB'),
(15, 'a12', '202cb962ac59075b964b07152d234b70', 'a12@bb.ua', 1, '2018-04-01 17:33:26', '2018-04-01 17:33:26', 'AAA BBBB'),
(16, 'a13', '202cb962ac59075b964b07152d234b70', 'a13@bb.ua', 1, '2018-04-01 17:34:49', '2018-04-01 17:34:49', 'AAA BBBB'),
(18, 'fedor', '202cb962ac59075b964b07152d234b70', 'mr_fedor@ukr.net', 1, '2018-04-15 11:32:28', '2018-04-15 11:32:28', 'Fedor Hsuryhin');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cpucash`
--
ALTER TABLE `cpucash`
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `processor`
--
ALTER TABLE `processor`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `products_processors`
--
ALTER TABLE `products_processors`
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `products_screens`
--
ALTER TABLE `products_screens`
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `ram`
--
ALTER TABLE `ram`
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `screen`
--
ALTER TABLE `screen`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `socket`
--
ALTER TABLE `socket`
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `uorders`
--
ALTER TABLE `uorders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `images`
--
ALTER TABLE `images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT для таблицы `processor`
--
ALTER TABLE `processor`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT для таблицы `screen`
--
ALTER TABLE `screen`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT для таблицы `uorders`
--
ALTER TABLE `uorders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
